import pandas as pd

# ================
# PREPROCESSING WEATHER DATA
# ================

# ✅ Load weather data
weather_df = pd.read_csv("Data Raw/NYC_Central_Park_weather_1869-2022.csv", usecols=["DATE", "PRCP", "SNOW", "TMIN", "TMAX"])
weather_df["Date"] = pd.to_datetime(weather_df["DATE"])
weather_df.drop(columns=["DATE"], inplace=True)
weather_df["SNOW"].fillna(0, inplace=True)
weather_df["TMIN"].interpolate(inplace=True)
weather_df["TMAX"].interpolate(inplace=True)

print("\n🌦️ Processed Weather Data:\n", weather_df.head())

# ================
# PREPROCESSING TRAFFIC DATA
# ================

# ✅ Load traffic data
traffic_df = pd.read_csv("Data Raw/Automated_Traffic_Volume_Counts_20250322.csv")
print("📝 Original Traffic Columns:\n", traffic_df.columns)

traffic_df.columns = traffic_df.columns.str.strip()

for col in ["Yr", "M", "D"]:
    traffic_df[col] = pd.to_numeric(traffic_df[col], errors="coerce")

traffic_df["Date"] = pd.to_datetime(
    traffic_df[['Yr', 'M', 'D']].astype(str).agg('-'.join, axis=1),
    format="%Y-%m-%d", errors="coerce"
)

traffic_df.drop(columns=["Yr", "M", "D"], inplace=True)

missing_dates = traffic_df["Date"].isna().sum()
if missing_dates > 0:
    print(f"\n🚨 Warning: {missing_dates} rows have invalid dates! Dropping them.")
    traffic_df = traffic_df.dropna(subset=["Date"])

traffic_df["toSt"].fillna("Unknown", inplace=True)

print("\n🚦 Processed Traffic Data:\n", traffic_df.head())

# ================
# MERGING TRAFFIC & WEATHER DATA
# ================

merged_df = traffic_df.merge(weather_df, on="Date", how="left")
merged_df.fillna({"PRCP": 0, "SNOW": 0, "TMIN": weather_df["TMIN"].median(), "TMAX": weather_df["TMAX"].median()}, inplace=True)

print("\n🔗 Merged Traffic & Weather Data:\n", merged_df.head())

# ================
# ADDING HOLIDAY INFORMATION
# ================

# ✅ Load US Holidays dataset
holidays_df = pd.read_csv("Data Raw/US Holiday Dates (2004-2021).csv")
holidays_df["Date"] = pd.to_datetime(holidays_df["Date"])
holidays_df["IsHoliday"] = 1

# ✅ Merge holiday info
merged_df = merged_df.merge(holidays_df[["Date", "IsHoliday"]], on="Date", how="left")
merged_df["IsHoliday"].fillna(0, inplace=True)  # Non-holiday = 0

print("\n🎉 Added Holiday Information:\n", merged_df[["Date", "IsHoliday"]].head())

# ================
# FINAL CLEANING
# ================

merged_df.drop_duplicates(inplace=True)

# Optionally: sort by Date
merged_df.sort_values("Date", inplace=True)

print("\n🔍 Missing Values After Merge:\n", merged_df.isnull().sum())
print("\n📏 Final Dataset Shape:", merged_df.shape)

# ================
# SAVE FINAL DATASET
# ================

merged_df.to_csv("Merge Data/final_z_data.csv", index=False)
print("\n💾 Final merged dataset saved as 'Merge Data/final_z_data.csv'")
