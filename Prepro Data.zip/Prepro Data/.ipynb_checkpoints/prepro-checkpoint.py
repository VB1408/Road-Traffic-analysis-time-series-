import pandas as pd  

# PREPROCESSING WEATHER DATA
# ✅ Load weather data  
weather_df = pd.read_csv("Data Raw/NYC_Central_Park_weather_1869-2022.csv", usecols=["DATE", "PRCP", "SNOW", "TMIN", "TMAX"])  

# ✅ Convert DATE column  
weather_df["Date"] = pd.to_datetime(weather_df["DATE"])  

# ✅ Drop old DATE column  
weather_df.drop(columns=["DATE"], inplace=True)  

# ✅ Handle missing values in weather data
weather_df["SNOW"].fillna(0, inplace=True)  # Assume missing snowfall as 0
weather_df["TMIN"].interpolate(inplace=True)  # Interpolation
weather_df["TMAX"].interpolate(inplace=True)  # Interpolation

# ✅ Show result  
print("\n🌦️ Processed Weather Data:\n", weather_df.head())  


# PREPROCESSING TRAFFIC DATA
# ✅ Load the Traffic Data
file_path = "Data Raw/Automated_Traffic_Volume_Counts_20250322.csv"
traffic_df = pd.read_csv(file_path)

# ✅ Print and Fix Column Names
print("📝 Original Column Names:\n", traffic_df.columns)
traffic_df.columns = traffic_df.columns.str.strip()  # Remove extra spaces

# ✅ Ensure 'Yr', 'M', and 'D' are Numeric
for col in ["Yr", "M", "D"]:
    traffic_df[col] = pd.to_numeric(traffic_df[col], errors="coerce")  # Convert to numbers

# ✅ Convert Yr, M, D to Date
traffic_df["Date"] = pd.to_datetime(
    traffic_df[['Yr', 'M', 'D']].astype(str).agg('-'.join, axis=1),  
    format="%Y-%m-%d", errors="coerce"
)
traffic_df.drop(columns=["Yr", "M", "D"], inplace=True)  # Drop old columns

# ✅ Handle Missing Dates
missing_dates = traffic_df["Date"].isna().sum()
if missing_dates > 0:
    print(f"\n🚨 Warning: {missing_dates} rows have invalid dates! Dropping them.")
    traffic_df = traffic_df.dropna(subset=["Date"])

# ✅ Fill Missing Destination Streets
traffic_df["toSt"].fillna("Unknown", inplace=True)

# ✅ Show Processed Data
print("\n🚦 Processed Traffic Data:\n", traffic_df.head())


# MERGING TRAFFIC & WEATHER DATA
# ✅ Merge on 'Date'
merged_df = traffic_df.merge(weather_df, on="Date", how="left")

# ✅ Fill any remaining missing weather values
merged_df.fillna({"PRCP": 0, "SNOW": 0, "TMIN": merged_df["TMIN"].median(), "TMAX": merged_df["TMAX"].median()}, inplace=True)

# ✅ Show Merged Data
print("\n🔗 Merged Traffic & Weather Data:\n", merged_df.head())


# FINAL CLEANING & CHECKS
# ✅ Drop Duplicates
merged_df.drop_duplicates(inplace=True)

# ✅ Check for Missing Values
print("\n🔍 Missing Values After Merge:\n", merged_df.isnull().sum())

# ✅ Show Final Dataset Shape
print("\n📏 Final Dataset Shape:", merged_df.shape)

# ✅ Save the merged data
merged_df.to_csv("Merge Data/final_dataset.csv", index=False)
print("\n💾 Merged dataset saved to 'Merge Data/final_dataset.csv'")
