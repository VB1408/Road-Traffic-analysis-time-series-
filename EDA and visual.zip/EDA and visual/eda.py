# 📌 IMPORTS
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller

# =====================================
# Step 1: Load, Filter & Deduplicate
# =====================================
df = pd.read_csv("Merge Data/final_dataset.csv", parse_dates=['Date'])
df = df.sort_values('Date')

# Filter: Keep data from 2009 onwards, exclude 2020
start_date, end_date = '2009-01-01', '2024-04-28'
mask = (df['Date'] >= start_date) & ~((df['Date'] >= '2020-01-01') & (df['Date'] <= '2020-12-31'))
df = df.loc[mask].drop_duplicates(subset=['Date'])

print(f"✅ Time series window: {df['Date'].min().date()} to {df['Date'].max().date()}")
print(f"✅ Filtered & deduplicated shape: {df.shape}\n")

# =====================================
# Step 2: Quick Stats on 20% Sample
# =====================================
sample = df.sample(frac=0.2, random_state=42)
print(f"🔢 Sample stats (20% of days):")
print(f"  • Volume Mean:     {sample['Vol'].mean():.2f}")
print(f"  • Volume Variance: {sample['Vol'].var():.2f}\n")

# =====================================
# Step 3: Build Daily Time Series
# =====================================
ts = df.set_index('Date')['Vol'].asfreq('D')     # Daily frequency
original_dates = ts.dropna().index                # Original non-NA points
ts_interp = ts.interpolate(method='time')         # Interpolate missing

print(f"🔍 Missing values before interpolation: {ts.isna().sum()}")
print(f"🔍 Missing values after interpolation:  {ts_interp.isna().sum()}\n")

# =====================================
# Step 4: Plot Original vs Interpolated
# =====================================
fig, ax = plt.subplots(figsize=(14,6))
ax.scatter(original_dates, ts.loc[original_dates], s=10, alpha=0.3, color='black', label='Original Data')
ax.plot(ts_interp.index, ts_interp.values, color='blue', linewidth=1, label='Interpolated Series')
ax.set_title("Original vs Interpolated Daily Traffic Volume")
ax.set_xlabel("Year")
ax.set_ylabel("Traffic Volume")
ax.legend()
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.tick_params(axis='x', rotation=45)
plt.tight_layout()
plt.show()
print("✅ Original vs Interpolated plot complete.\n")

# =====================================
# Step 5: Decomposition
# =====================================
decomp = seasonal_decompose(ts_interp, model='additive', period=180)

fig, axes = plt.subplots(4, 1, figsize=(14, 10))
titles = ["Observed Volume", "Trend Component", "Seasonal Component", "Residuals"]
colors = ["black", "blue", "green", "red"]

for ax, comp, title, color in zip(axes, [ts_interp, decomp.trend, decomp.seasonal, decomp.resid], titles, colors):
    ax.plot(comp, color=color)
    ax.set_title(title)
    ax.set_ylabel("Traffic Volume")
    ax.set_xlabel("Year")
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.show()
print("✅ Decomposition plots complete.\n")

# =====================================
# Step 6: Differencing & Visualization
# =====================================
# Log transform
ts_log = np.log1p(ts_interp)

# Second differencing (remove trend)
ts_diff2 = ts_log.diff().diff()

# Seasonal differencing (remove seasonality - 365 days lag)
ts_seas365 = ts_diff2.diff(365)

fig, axes = plt.subplots(3, 1, figsize=(14, 8))
titles = ["Log1p Transform (Before Differencing)",
          "Second-Order Differencing (Remove Trend)",
          "Seasonal Differencing (Remove Seasonality, 365 days)"]
datas = [ts_log, ts_diff2, ts_seas365]
colors = ["black", "orange", "green"]

for ax, data, title, color in zip(axes, datas, titles, colors):
    ax.plot(data, color=color)
    ax.set_title(title)
    ax.set_ylabel("Traffic Volume")
    ax.set_xlabel("Year")
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.show()
print("✅ Differencing plots complete.\n")

# =====================================
# Step 7: Stationarity Checks (ADF Test)
# =====================================
def adf_test(series, label):
    result = adfuller(series.dropna(), autolag='AIC')
    stat, pval, crit = result[0], result[1], result[4]
    print(f"\n📌 ADF Test — {label}")
    print(f"  • Statistic: {stat:.4f}")
    print(f"  • p-value:   {pval:.4f}")
    for key, value in crit.items():
        print(f"    {key}% critical value: {value:.4f}")
    verdict = "Stationary ✅" if pval <= 0.05 else "Non-Stationary ⚠️"
    print(f"  ➞ {verdict}")

# Run ADF Tests
adf_test(ts_interp, "Interpolated Series (Before Diff)")
adf_test(ts_log, "Log-Transformed Series")
adf_test(ts_diff2, "After Second-Order Differencing")
adf_test(ts_seas365, "After Seasonal Differencing (365 days)")
print("\n✅ All ADF tests completed successfully.")

# =====================================
# Step 8: Save Final Model Training Data
# =====================================
model_ready_df = pd.DataFrame({
    'Date': ts_interp.index,
    'Vol': ts_interp.values
})
model_ready_df.to_csv("model_training.csv", index=False)
print("\n💾 Model-ready training data saved to 'model_training.csv' ✅")










#####################model Training###

# =====================================
# Step 8: ACF and PACF Plots
# =====================================
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

print("\n🔎 Generating ACF and PACF plots...\n")

# We'll use the final differenced and logged series for ACF/PACF
fig, axes = plt.subplots(2, 1, figsize=(14, 8))

# ACF: Autocorrelation Plot
plot_acf(ts_seas365.dropna(), lags=50, ax=axes[0])
axes[0].set_title("Autocorrelation Function (ACF)")

# PACF: Partial Autocorrelation Plot
plot_pacf(ts_seas365.dropna(), lags=50, ax=axes[1], method='ywm')
axes[1].set_title("Partial Autocorrelation Function (PACF)")

plt.tight_layout()
plt.show()

print("✅ ACF and PACF plots generated successfully.\n")
