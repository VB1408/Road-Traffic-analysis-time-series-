import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load Final Dataset (Use a Subset for Efficiency)
df = pd.read_csv("Merge Data/final_dataset.csv")

# Use 20% of the data for EDA
sample_frac = 0.2
df_sampled = df.sample(frac=sample_frac, random_state=42)
print(f"Using {sample_frac * 100}% of the data: {df_sampled.shape} out of {df.shape}")

# Basic Info
print("\n🔍 Dataset Info:")
df_sampled.info()

# Check Missing Values
print("\n🚨 Missing Values:")
print(df_sampled.isnull().sum())

# Descriptive Statistics
print("\n📊 Summary Statistics:")
print(df_sampled.describe())

# Visualization Setup
sns.set_style("whitegrid")

# Traffic Volume Distribution
plt.figure(figsize=(8,5))
sns.histplot(df_sampled['Vol'], bins=30, kde=True, color='blue')
plt.title("Traffic Volume Distribution")
plt.xlabel("Volume")
plt.ylabel("Frequency")
plt.show()

# Time-Series Analysis
plt.figure(figsize=(12,5))
df_sampled.groupby('Date')['Vol'].mean().plot()
plt.title("Average Traffic Volume Over Time")
plt.xlabel("Date")
plt.ylabel("Avg Volume")
plt.xticks(rotation=45)
plt.show()

# Correlation Heatmap
plt.figure(figsize=(10,6))
sns.heatmap(df_sampled.corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title("Feature Correlation Heatmap")
plt.show()

# Weather Impact on Traffic
plt.figure(figsize=(8,5))
sns.boxplot(x='PRCP', y='Vol', data=df_sampled)
plt.title("Impact of Precipitation on Traffic Volume")
plt.xlabel("Precipitation (PRCP)")
plt.ylabel("Traffic Volume")
plt.show()

# Anomaly Detection in Traffic Volume
plt.figure(figsize=(8,5))
sns.boxplot(df_sampled['Vol'], color='red')
plt.title("Outlier Detection in Traffic Volume")
plt.show()

print("\n✅ EDA Completed - Insights Ready!")